This folder contains consolidated Eagle and Gerber files of all required EEZ PSU modules:
 * Power module **r5B9** (two per unit)
 * Auxiliary power supply **r5B9**
 * Arduino shield **r3B4** (digital control)

All components are renumbered that single BOM can be used. PCB panel is created with four boards to decrease setup fee of PCB manufacturing and assembling.