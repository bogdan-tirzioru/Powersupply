**Arduino Shield r3B4**
- Marking on bottom silkscreen for all red LEDs (LED_SP, LED_PROG1, LED_PROG2, LED_CC1, LED_CC2) is wrong (cathode and anode are swapped on HSMH-C170)
- X18 has to be right angled since it is positioned too close to the CH1 heatsink

**AUX PS r5B9**
- Side 2 of USB isolator (IC19) has no power connected. Add wiring from X10-1 to pin 16 and X10-4 to pin 9 if you'd like to add USB isolation.

**Power module r5B9**
- No known issues

