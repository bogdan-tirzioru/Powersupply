#ifndef _IO_
#define _IO_

extern void io_init(void);


#endif
