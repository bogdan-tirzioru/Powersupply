#ifndef _string_proc_
#define _string_proc_
void ConvertZecimalToAsci(T_SWORD sw_ADCT0,T_UBYTE ub_lenght);
void ConvertHexToAsci32(T_ULONG lul_data_read);
T_ULONG ExtractAdrressReq(void);
T_UBYTE Read_data_from_address8(T_ULONG lul_address_request);
#endif
