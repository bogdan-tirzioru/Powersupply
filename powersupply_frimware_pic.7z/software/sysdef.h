#ifndef _SYSDEF_
#define _SYSDEF_
 #include "uart.h"
 #define PWM_DRIVER_ENABLE 1
 #define ADC_DRIVER_ENABLE 1
 #define USART_DRIVER_ENABLE 0
 #define XTAL (4000000)
 #define SYSCLOCK XTAL/4
#endif
