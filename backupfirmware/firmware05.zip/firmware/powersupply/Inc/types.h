#ifndef _TYPES_
#define _TYPES_
typedef unsigned char T_UBYTE;
typedef unsigned short int T_UWORD; 
typedef unsigned long int T_ULONG; 
typedef signed char T_SBYTE;
typedef signed int T_SWORD; 
typedef signed long int T_SLONG;
#endif
